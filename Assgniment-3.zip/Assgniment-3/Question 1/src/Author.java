public class Author {
//Declaring the private variables 

    private String name;
    private String email;
    private char gender;

    public Author(String name, String email, char gender) {
        this.name = name;
        this.email = email;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public char getGender() {
        return gender;
    }

    public void setEmail(String email) {
        this.email = email;
    }
//Printing the output to main class
    @Override
    public String toString() {
        return "Author Information: " +  name +   ",  " + "Email: " +  email +  ",  " + "Gender: " + gender ;
    }
//Main Class

    public static void main(String[] args) {
        Author washington = new Author ("Nicki Washington", "washingtonn@winthrop.edu", 'f');
        System.out.println(washington);
    }
}