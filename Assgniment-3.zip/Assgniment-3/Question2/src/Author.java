
public class Author {
//Declaring the private variables 

    private String name;
    private String email;
    private char gender;

    public Author(String name, String email, char gender) {
        this.name = name;
        this.email = email;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public char getGender() {
        return gender;
    }

    public void setEmail(String email) {
        this.email = email;
    }
//Printing the output to main class

    @Override
    public String toString() {
        return "Author Information: " + name + ",  " + "Email: " + email + ",  " + "Gender: " + gender;
    }

}

class Book {
//declaring the private variables 
    private String name;
    private Author author;
    private double price;
    private int qtyInStock;

    public Book(String name, Author author, double price, int qtyInStock)
    {
        this.name = name;
        this.author = author;
        this.price = price;
        this.qtyInStock = qtyInStock;
    }

//get and set methods
    public String getName() {
        return name;
    }

    public Author getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQtyInStock() {
        return qtyInStock;
    }

    public void setQtyInStock(int qtyInStock) {
        this.qtyInStock = qtyInStock;
    }
// printing the output to main method 

    @Override
    public String toString() {
        return "Book Name : " + name + "  Price: $" + price + "  Quantity in stock: " + qtyInStock + "  " + author.toString();
    }

    // Main Method
    public static void main(String[] args) {
        //Test method one
        Author washington = new Author("Nicki Washington", "washingtonn@winthrop.edu", 'f');
        System.out.println(washington);

        Book toc = new Book("Stay Prepped: 10 Steps to Succeeding in College (and Having a Ball Doing It)!", washington, 14.95, 1908);
        System.out.println(toc);

        // Test method two
        Book toc1 = new Book("Stay Prepped: 10 Steps to Succeeding in College (and Having a Ball Doing It)!", new Author("Nicki Washington", "washingtonn@winthrop.edu", 'f'), 14.95, 1908);
        System.out.println("Book Name : " + toc1.getName() + "  Price : $" + toc1.getPrice() + " Quantity in stock : " + toc1.getQtyInStock());

        System.out.println(toc1.getAuthor());

    }

}
