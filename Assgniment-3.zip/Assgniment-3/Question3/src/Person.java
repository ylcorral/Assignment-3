// Class for Person

public class Person {
// Variables

    protected String myName;
    protected int myAge;
    protected String myGender;

    //main method
    public static void main(String[] args) {
        //Test Cases 
        Person bob = new Person("Coach Bob", 27, "M");
        System.out.println(bob);
        Student lynne = new Student("Lynne Brooke", 16, "F", "HS95129", 3.5);
        System.out.println(lynne);
        Teacher mrJava = new Teacher("Duke Java", 34, "M", "Computer Science", 50000);
        System.out.println(mrJava);
        CollegeStudent ima = new CollegeStudent("Ima Frosh", 18, "F", "UCB123", 4.0, 1, "English");
        System.out.println(ima);
    }

    public Person(String name, int age, String gender) {
        myName = name;
        myAge = age;
        myGender = gender;
    }

    @Override
    public String toString() {
        return myName + ", age: " + myAge + ", gender: " + myGender;
    }

    public String getName() {
        return myName;
    }

    public void setName(String name) {
        this.myName = name;
    }

    public int getAge() {
        return myAge;
    }

    public void setAge(int age) {
        this.myAge = age;
    }

    public String getGender() {
        return myGender;
    }

    public void setGender(String gender) {
        this.myGender = gender;
    }
}
//Class for Student 

class Student extends Person {
// Variables 

    protected String myIdNum;
    protected double myGPA;

    public Student(String name, int age, String gender, String idNum, double gpa) {
        super(name, age, gender);
        myIdNum = idNum;
        myGPA = gpa;
    }

    public String getIdNum() {
        return myIdNum;
    }

    public void setIdNum(String myIdNum) {
        this.myIdNum = myIdNum;
    }

    public double getGpa() {
        return myGPA;
    }

    public void setGpa(double myGPA) {
        this.myGPA = myGPA;
    }

    @Override
    public String toString() {
        return "Student: \n" + super.toString()
                + "\nID Number: " + myIdNum
                + "\nGPA: " + myGPA;
    }
}
// Class for Teacher 

class Teacher extends Person {
// Variables 

    protected String subject;
    protected double salary;

    public Teacher(String myName, int myAge, String myGender, String subject, double salary) {
        super(myName, myAge, myGender);
        this.subject = subject;
        this.salary = salary;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Teacher: \n" + super.toString()
                + "\nSubject:  " + subject
                + "\nSalary:  " + salary;
    }
}
//Class for College Student

class CollegeStudent extends Student {
// Variables 

    protected String major;
    protected int year;

    public CollegeStudent(String myName, int myAge, String myGender, String myIdNum, double myGPA, int year, String major) {
        super(myName, myAge, myGender, myIdNum, myGPA);
        this.major = major;
        this.year = year;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nMajor: " + major
                + "\nYear: " + year;
    }
}
